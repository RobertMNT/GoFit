"use client";

import dynamic from "next/dynamic";
import { Component, type ReactNode } from "react";

// Fallback visual cuando WebGL no está disponible o falla
function HeroFallback() {
  return (
    <div className="flex h-full items-center justify-center">
      <div className="text-center opacity-20">
        <div className="mx-auto mb-4 h-24 w-24 rounded-full border-4 border-blue-500/40 bg-blue-500/10" />
        <p className="text-sm text-gray-500">FitAI</p>
      </div>
    </div>
  );
}

// Error boundary para capturar fallos de WebGL/Three.js
class WebGLBoundary extends Component<{ children: ReactNode }, { crashed: boolean }> {
  state = { crashed: false };
  componentDidCatch() {
    this.setState({ crashed: true });
  }
  render() {
    if (this.state.crashed) return <HeroFallback />;
    return this.props.children;
  }
}

// Wrapper cliente necesario: ssr:false no está permitido en Server Components
const HeroSection = dynamic(
  () => import("./hero-section").then((m) => m.HeroSection),
  {
    ssr: false,
    loading: () => (
      <div className="flex min-h-screen items-center justify-center bg-[#030712]">
        <div className="h-2 w-32 overflow-hidden rounded-full bg-white/10">
          <div className="h-full w-1/2 animate-pulse rounded-full bg-blue-500" />
        </div>
      </div>
    ),
  },
);

export function HeroWrapper() {
  return (
    <WebGLBoundary>
      <HeroSection />
    </WebGLBoundary>
  );
}
