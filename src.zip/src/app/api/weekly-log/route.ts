import { createClient } from "@/lib/supabase/server";
import { NextResponse } from "next/server";
import { z } from "zod";

// Schema de entrada para registrar/actualizar un log semanal
const requestSchema = z.object({
  plan_id: z.string().uuid(),
  semana: z.number().int().min(1),
  dia: z.string().min(1),
  completado: z.boolean(),
  notas: z.string().nullable().optional(),
});

export async function POST(request: Request) {
  try {
    const supabase = await createClient();

    // Verificar autenticación
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "No autenticado" }, { status: 401 });
    }

    // Verificar que el usuario es PRO (nunca confiar solo en el cliente)
    const { data: profile } = await supabase
      .from("users")
      .select("role")
      .eq("id", user.id)
      .single();

    if (profile?.role !== "pro") {
      return NextResponse.json(
        { error: "El seguimiento semanal es una función exclusiva del plan PRO" },
        { status: 403 },
      );
    }

    // Validar body
    const body = await request.json();
    const parsed = requestSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Parámetros inválidos" }, { status: 400 });
    }

    const { plan_id, semana, dia, completado, notas } = parsed.data;

    // Verificar que el plan pertenece al usuario (RLS también lo garantiza, doble verificación)
    const { data: plan } = await supabase
      .from("plans")
      .select("id")
      .eq("id", plan_id)
      .eq("user_id", user.id)
      .single();

    if (!plan) {
      return NextResponse.json({ error: "Plan no encontrado" }, { status: 404 });
    }

    // Upsert — si ya existe el registro para ese (plan, semana, día) lo actualiza, si no lo crea
    const { data, error } = await supabase
      .from("weekly_logs")
      .upsert(
        {
          user_id: user.id,
          plan_id,
          semana,
          dia,
          completado,
          notas: notas ?? null,
        },
        {
          onConflict: "user_id,plan_id,semana,dia",
        },
      )
      .select("id, completado")
      .single();

    if (error) {
      return NextResponse.json({ error: "Error al guardar el log" }, { status: 500 });
    }

    return NextResponse.json(data, { status: 200 });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Error interno";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
