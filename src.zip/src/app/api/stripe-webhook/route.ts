import { stripe } from "@/lib/stripe";
import { createClient } from "@/lib/supabase/server";
import { headers } from "next/headers";
import { NextResponse } from "next/server";
import type Stripe from "stripe";

// Eventos de Stripe que manejamos
const EVENTOS_RELEVANTES = new Set([
  "checkout.session.completed",
  "customer.subscription.created",
  "customer.subscription.updated",
  "customer.subscription.deleted",
]);

export async function POST(request: Request) {
  const body = await request.text();
  const headersList = await headers();
  const signature = headersList.get("stripe-signature");

  if (!signature) {
    return NextResponse.json({ error: "Firma ausente" }, { status: 400 });
  }

  let event: Stripe.Event;

  try {
    // Verificar la firma del webhook para prevenir peticiones falsas
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch {
    return NextResponse.json({ error: "Firma inválida" }, { status: 400 });
  }

  if (!EVENTOS_RELEVANTES.has(event.type)) {
    return NextResponse.json({ received: true });
  }

  const supabase = await createClient();

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        // La suscripción se gestiona en customer.subscription.created
        if (session.mode !== "subscription") break;
        break;
      }

      case "customer.subscription.created":
      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription;
        await upsertSubscription(supabase, subscription);
        break;
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        await cancelSubscription(supabase, subscription);
        break;
      }
    }
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Error procesando webhook";
    return NextResponse.json({ error: message }, { status: 500 });
  }

  return NextResponse.json({ received: true });
}

// Crea o actualiza una suscripción y ajusta el rol del usuario
async function upsertSubscription(
  supabase: Awaited<ReturnType<typeof createClient>>,
  subscription: Stripe.Subscription,
) {
  const userId = subscription.metadata?.supabase_user_id;
  if (!userId) return;

  const item = subscription.items.data[0];
  const esActiva = subscription.status === "active" || subscription.status === "trialing";

  // Guardar/actualizar la suscripción
  await supabase.from("subscriptions").upsert(
    {
      user_id: userId,
      stripe_subscription_id: subscription.id,
      stripe_customer_id: subscription.customer as string,
      status: subscription.status,
      price_id: item.price.id,
      current_period_start: new Date(item.current_period_start * 1000).toISOString(),
      current_period_end: new Date(item.current_period_end * 1000).toISOString(),
      cancel_at_period_end: subscription.cancel_at_period_end,
    },
    { onConflict: "stripe_subscription_id" },
  );

  // Actualizar el rol del usuario según el estado de la suscripción
  await supabase
    .from("users")
    .update({ role: esActiva ? "pro" : "free" })
    .eq("id", userId);
}

// Cancela la suscripción y revoca el acceso PRO
async function cancelSubscription(
  supabase: Awaited<ReturnType<typeof createClient>>,
  subscription: Stripe.Subscription,
) {
  const userId = subscription.metadata?.supabase_user_id;
  if (!userId) return;

  await supabase
    .from("subscriptions")
    .update({ status: "canceled" })
    .eq("stripe_subscription_id", subscription.id);

  // Degradar a free al cancelar la suscripción
  await supabase.from("users").update({ role: "free" }).eq("id", userId);
}
