import { createClient } from "@/lib/supabase/server";
import type { Subscription, UserProfile } from "@/types/database";
import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { ProfileClient } from "@/components/profile/profile-client";

export const metadata: Metadata = {
  title: "Mi perfil",
};

export default async function PerfilPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const [{ data: profile }, { data: subscription }] = await Promise.all([
    supabase.from("users").select("*").eq("id", user.id).single(),
    supabase
      .from("subscriptions")
      .select("*")
      .eq("user_id", user.id)
      .eq("status", "active")
      .maybeSingle(),
  ]);

  return (
    <ProfileClient
      profile={profile as UserProfile}
      subscription={subscription as Subscription | null}
    />
  );
}
