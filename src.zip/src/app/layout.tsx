import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { CookieBanner } from "@/components/cookie-banner";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

// Metadata SEO base para FitAI
export const metadata: Metadata = {
  title: {
    default: "FitAI — Planes de entrenamiento personalizados por IA",
    template: "%s | FitAI",
  },
  description:
    "Genera tu plan de entrenamiento y bienestar personalizado con inteligencia artificial. Gratis para empezar, PRO para maximizar resultados.",
  keywords: ["entrenamiento", "fitness", "IA", "planes personalizados", "bienestar", "ejercicio"],
  authors: [{ name: "FitAI" }],
  creator: "FitAI",
  metadataBase: new URL("https://fitai.app"),
  openGraph: {
    type: "website",
    locale: "es_ES",
    url: "https://fitai.app",
    title: "FitAI — Planes de entrenamiento personalizados por IA",
    description:
      "Genera tu plan de entrenamiento y bienestar personalizado con inteligencia artificial.",
    siteName: "FitAI",
  },
  twitter: {
    card: "summary_large_image",
    title: "FitAI — Planes de entrenamiento personalizados por IA",
    description:
      "Genera tu plan de entrenamiento y bienestar personalizado con inteligencia artificial.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>
        {children}
        <CookieBanner />
      </body>
    </html>
  );
}
