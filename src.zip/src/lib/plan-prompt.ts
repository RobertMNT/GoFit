import type { QuestionnaireData } from "./questionnaire-schema";

// Descripción legible de las opciones del cuestionario
const OBJETIVOS: Record<string, string> = {
  perder_peso: "perder peso y reducir grasa corporal",
  ganar_musculo: "ganar masa muscular e hipertrofia",
  mejorar_resistencia: "mejorar la resistencia cardiovascular y la capacidad aeróbica",
  bienestar_general: "mejorar el bienestar general, la salud y la condición física",
};

const NIVELES: Record<string, string> = {
  principiante: "principiante (menos de 6 meses de experiencia)",
  intermedio: "intermedio (6 meses a 2 años)",
  avanzado: "avanzado (más de 2 años entrenando)",
};

const ACTIVIDAD: Record<string, string> = {
  sedentario: "sedentario (trabajo de oficina, poco movimiento)",
  ligero: "ligero (camina un poco al día)",
  moderado: "moderado (activo durante el día)",
  activo: "muy activo (trabajo físico o mucho deporte fuera del plan)",
};

// Construye el prompt del sistema para la generación de planes
export function buildPlanPrompt(answers: QuestionnaireData): string {
  const equipamientoLista = answers.equipamiento.join(", ");
  const restriccionesTexto =
    answers.restricciones.trim() || "ninguna lesión o restricción indicada";

  return `Eres un entrenador personal certificado y experto en programación de entrenamientos.
Tu tarea es crear un plan de entrenamiento personalizado y detallado en formato JSON estructurado.

## Perfil del usuario
- Objetivo: ${OBJETIVOS[answers.objetivo]}
- Nivel: ${NIVELES[answers.nivel]}
- Días disponibles por semana: ${answers.dias_por_semana}
- Duración por sesión: ${answers.duracion_sesion} minutos
- Lugar de entrenamiento: ${answers.lugar_entreno}
- Equipamiento disponible: ${equipamientoLista}
- Sexo: ${answers.sexo}
- Edad: ${answers.edad} años
- Peso: ${answers.peso_kg} kg
- Altura: ${answers.altura_cm} cm
- Nivel de actividad diaria: ${ACTIVIDAD[answers.nivel_actividad_diaria]}
- Restricciones/lesiones: ${restriccionesTexto}

## Instrucciones para el plan
1. Crea un plan de ${answers.dias_por_semana === 2 ? 4 : answers.dias_por_semana === 3 ? 6 : 8} semanas de duración
2. Distribuye los ${answers.dias_por_semana} días de entrenamiento semanales de forma óptima
3. Cada sesión debe caber en ${answers.duracion_sesion} minutos
4. Adapta todos los ejercicios al equipamiento disponible y al lugar de entrenamiento
5. Evita ejercicios que puedan agravar las restricciones indicadas
6. Incluye calentamiento implícito en las notas cuando sea necesario
7. Progresión gradual de semana en semana (volumen e intensidad)

## Formato de respuesta — SOLO JSON, sin texto adicional

Responde ÚNICAMENTE con un objeto JSON que siga esta estructura exacta:

{
  "nombre": "string — nombre motivador del plan (ej: 'Plan Fuerza Base 6 semanas')",
  "descripcion": "string — descripción de 2-3 líneas del plan, qué conseguirá el usuario",
  "duracion_semanas": number,
  "semanas": [
    {
      "semana": 1,
      "dias": [
        {
          "dia": "lunes",
          "tipo": "fuerza | cardio | flexibilidad | descanso_activo",
          "ejercicios": [
            {
              "nombre": "string",
              "series": number,
              "repeticiones": "string (ej: '8-12' o '45 segundos')",
              "descanso_segundos": number,
              "notas": "string | null — técnica o progresión importante"
            }
          ]
        }
      ]
    }
  ]
}

IMPORTANTE:
- Los días de descanso deben incluirse como día con tipo "descanso_activo" y array ejercicios vacío
- Las repeticiones siempre como string para soportar rangos y duraciones
- El JSON debe ser válido y parseable directamente
- No incluyas markdown, explicaciones ni texto fuera del JSON`;
}
