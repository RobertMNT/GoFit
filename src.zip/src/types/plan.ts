import { z } from "zod";

// Schema Zod para validar la respuesta JSON de la IA
export const exerciseSchema = z.object({
  nombre: z.string().min(1),
  series: z.number().int().min(1),
  repeticiones: z.string().min(1),
  descanso_segundos: z.number().int().min(0),
  notas: z.string().nullable(),
});

export const dayPlanSchema = z.object({
  dia: z.string().min(1),
  tipo: z.enum(["fuerza", "cardio", "flexibilidad", "descanso_activo"]),
  ejercicios: z.array(exerciseSchema),
});

export const weeklyPlanSchema = z.object({
  semana: z.number().int().min(1),
  dias: z.array(dayPlanSchema).min(1),
});

export const fitnessPlanResponseSchema = z.object({
  nombre: z.string().min(1),
  descripcion: z.string().min(1),
  duracion_semanas: z.number().int().min(1),
  semanas: z.array(weeklyPlanSchema).min(1),
});

export type FitnessPlanResponse = z.infer<typeof fitnessPlanResponseSchema>;
export type Exercise = z.infer<typeof exerciseSchema>;
export type DayPlan = z.infer<typeof dayPlanSchema>;
export type WeeklyPlan = z.infer<typeof weeklyPlanSchema>;
