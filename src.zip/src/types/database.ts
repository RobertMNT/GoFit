// Tipos que reflejan el esquema de base de datos de Supabase

export type UserRole = "free" | "pro";

export interface UserProfile {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  role: UserRole;
  stripe_customer_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface Questionnaire {
  id: string;
  user_id: string;
  answers: QuestionnaireAnswers;
  created_at: string;
}

export interface QuestionnaireAnswers {
  objetivo: string;           // perder peso | ganar músculo | mejorar resistencia | bienestar general
  nivel: string;              // principiante | intermedio | avanzado
  dias_por_semana: number;    // 2 | 3 | 4 | 5
  duracion_sesion: number;    // minutos por sesión: 30 | 45 | 60 | 90
  lugar_entreno: string;      // casa | gimnasio | exterior
  equipamiento: string[];     // mancuernas | barra | máquinas | bandas | sin equipamiento
  restricciones: string;      // lesiones o limitaciones físicas
  edad: number;
  sexo: string;               // hombre | mujer | prefiero no decirlo
  peso_kg: number;
  altura_cm: number;
  nivel_actividad_diaria: string; // sedentario | ligero | moderado | activo
}

export interface FitnessPlan {
  id: string;
  user_id: string;
  questionnaire_id: string;
  nombre: string;
  descripcion: string;
  duracion_semanas: number;
  semanas: WeeklyPlan[];
  created_at: string;
  updated_at: string;
}

export interface WeeklyPlan {
  semana: number;
  dias: DayPlan[];
}

export interface DayPlan {
  dia: string;   // lunes | martes | ...
  tipo: string;  // fuerza | cardio | flexibilidad | descanso
  ejercicios: Exercise[];
}

export interface Exercise {
  nombre: string;
  series: number;
  repeticiones: string;  // "8-12" | "15" | "30 segundos"
  descanso_segundos: number;
  notas: string | null;
}

export interface WeeklyLog {
  id: string;
  user_id: string;
  plan_id: string;
  semana: number;
  dia: string;
  completado: boolean;
  notas: string | null;
  created_at: string;
}

export interface Subscription {
  id: string;
  user_id: string;
  stripe_subscription_id: string;
  stripe_customer_id: string;
  status: SubscriptionStatus;
  price_id: string;
  current_period_start: string;
  current_period_end: string;
  cancel_at_period_end: boolean;
  created_at: string;
  updated_at: string;
}

export type SubscriptionStatus =
  | "active"
  | "canceled"
  | "incomplete"
  | "incomplete_expired"
  | "past_due"
  | "trialing"
  | "unpaid";
